# -*- coding: utf-8 -*-
'''
    :file: settings.py
    :author: -Farmer
    :url: https://blog.farmer233.top
    :date: 2021/09/02 22:29:51
'''

# HOST = '172.16.1.28'
# 登录
LOGIN_API_URL = "/zfcaptchaLogin"
LOGIN_PAGE_URL = '/xtgl/login_slogin.html'
RSA_KEY_URL = '/xtgl/login_getPublicKey.html'

# 
PERSON_SCHEDULE_URL = "/kbcx/xskbcx_cxXskbcxIndex.html"
PERSON_SCHEDULE_API = '/kbcx/xskbcx_cxXsKb.html'

# Code config
RTK_RE_KEY = "tk:'(.*)',"

LOGIN_EXTEND = b'{"appName":"Netscape","userAgent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.159 Safari/537.36","appVersion":"5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.159 Safari/537.36"}'

